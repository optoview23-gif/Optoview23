const CACHE_NAME = 'optoview-v10';
const ASSETS = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if(event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => {
    if(cached) return cached;
    return fetch(event.request).then(response => {
      if(!response || response.status !== 200) return response;
      caches.open(CACHE_NAME).then(c => c.put(event.request, response.clone()));
      return response;
    });
  }));
});
